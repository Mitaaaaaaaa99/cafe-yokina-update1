// ===== NAVBAR: Hide topbar on scroll =====
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  if (window.scrollY > 60) navbar.classList.add('scrolled');
  else navbar.classList.remove('scrolled');
});

// ===== HAMBURGER MENU =====
const hamburger = document.getElementById('hamburger-menu');
const navMenu = document.getElementById('navMenu');
hamburger.addEventListener('click', (e) => {
  navMenu.classList.toggle('active');
  e.stopPropagation();
});
document.addEventListener('click', (e) => {
  if (!navMenu.contains(e.target) && !hamburger.contains(e.target)) {
    navMenu.classList.remove('active');
  }
});
navMenu.querySelectorAll('a').forEach(a => {
  a.addEventListener('click', () => navMenu.classList.remove('active'));
});

// ===== HERO SLIDESHOW =====
const slides = document.querySelectorAll('.slide');
const dots = document.querySelectorAll('.dot');
let currentSlide = 0;
let slideTimer;

function goToSlide(n) {
  slides[currentSlide].classList.remove('active');
  dots[currentSlide].classList.remove('active');
  currentSlide = (n + slides.length) % slides.length;
  slides[currentSlide].classList.add('active');
  dots[currentSlide].classList.add('active');
}

function nextSlide() { goToSlide(currentSlide + 1); }
function prevSlide() { goToSlide(currentSlide - 1); }

function startAutoSlide() {
  clearInterval(slideTimer);
  slideTimer = setInterval(nextSlide, 5000);
}

document.getElementById('slideNext').addEventListener('click', () => { nextSlide(); startAutoSlide(); });
document.getElementById('slidePrev').addEventListener('click', () => { prevSlide(); startAutoSlide(); });
dots.forEach((dot, i) => dot.addEventListener('click', () => { goToSlide(i); startAutoSlide(); }));
startAutoSlide();

// ===== REVIEWS CAROUSEL =====
const track = document.getElementById('reviewsTrack');
const cards = track.querySelectorAll('.review-card');
let revIndex = 0;
const visibleCards = () => window.innerWidth < 700 ? 1 : window.innerWidth < 1000 ? 2 : 3;

function updateReviews() {
  const cardWidth = cards[0].offsetWidth + 24; // gap
  const max = cards.length - visibleCards();
  if (revIndex > max) revIndex = max;
  if (revIndex < 0) revIndex = 0;
  track.style.transform = `translateX(-${revIndex * cardWidth}px)`;
}

document.getElementById('revNext').addEventListener('click', () => { revIndex++; updateReviews(); });
document.getElementById('revPrev').addEventListener('click', () => { revIndex--; updateReviews(); });
window.addEventListener('resize', updateReviews);

// ===== FEATHER ICONS =====
feather.replace();

// ===== PARTIES DROPDOWN NAV =====
const partiesWrap = document.getElementById('partiesWrap');
const partiesToggle = document.getElementById('partiesToggle');
if (partiesToggle) {
  partiesToggle.addEventListener('click', (e) => {
    e.preventDefault();
    partiesWrap.classList.toggle('open');
  });
  document.addEventListener('click', (e) => {
    if (!partiesWrap.contains(e.target)) partiesWrap.classList.remove('open');
  });
  document.querySelectorAll('.parties-dd-item').forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const sub = item.getAttribute('data-sub');
      partiesWrap.classList.remove('open');
      switchPartiesSub(sub);
      document.getElementById('parties').scrollIntoView({ behavior: 'smooth' });
    });
  });
}

// ===== PARTIES SUB SWITCHER =====
function switchPartiesSub(sub) {
  document.querySelectorAll('.parties-sub').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.parties-sub-btn').forEach(b => b.classList.remove('active'));
  const target = document.getElementById('sub-' + sub);
  if (target) target.classList.add('active');
  const btn = document.querySelector('.parties-sub-btn[data-sub="' + sub + '"]');
  if (btn) btn.classList.add('active');
}

function openPartiesSub(sub) {
  switchPartiesSub(sub);
  const section = document.getElementById('parties');
  if (section) setTimeout(() => section.scrollIntoView({ behavior: 'smooth' }), 50);
}

// ===== PACKAGE SELECTION =====
function selectPackage(el, name, price) {
  document.querySelectorAll('.pkg-card').forEach(c => c.classList.remove('selected'));
  el.classList.add('selected');
  const pkgInput = document.getElementById('b-package');
  if (pkgInput) pkgInput.value = name + ' (Rp ' + price + ')';
}

// ===== SEND BOOKING EMAIL =====
function sendBookingEmail() {
  const name = (document.getElementById('b-name') || {}).value || '';
  const phone = (document.getElementById('b-phone') || {}).value || '';
  const date = (document.getElementById('b-date') || {}).value || '';
  const time = (document.getElementById('b-time') || {}).value || '';
  const guests = (document.getElementById('b-guests') || {}).value || '';
  const type = (document.getElementById('b-type') || {}).value || '';
  const pkg = (document.getElementById('b-package') || {}).value || '';
  const notes = (document.getElementById('b-notes') || {}).value || '';

  if (!name.trim() || !phone.trim() || !date) {
    alert('Mohon isi Nama, No HP, dan Tanggal Acara terlebih dahulu.');
    return;
  }

  const subject = encodeURIComponent('Booking Event Café Yokina – ' + name);
  const body = encodeURIComponent(
    'Halo Admin Café Yokina,\n\n' +
    'Ada permintaan booking event:\n\n' +
    'Nama      : ' + name + '\n' +
    'No HP/WA  : ' + phone + '\n' +
    'Tanggal   : ' + date + '\n' +
    'Jam       : ' + (time || '-') + '\n' +
    'Jml Tamu  : ' + (guests || '-') + '\n' +
    'Jenis Acara: ' + (type || '-') + '\n' +
    'Paket     : ' + (pkg || '-') + '\n' +
    'Catatan   : ' + (notes || '-') + '\n\n' +
    'Terima kasih!'
  );

  window.open('mailto:admin@cafeyokina.com?subject=' + subject + '&body=' + body, '_blank');

  const successEl = document.getElementById('bookingSuccess');
  if (successEl) successEl.style.display = 'block';
  setTimeout(() => { if (successEl) successEl.style.display = 'none'; }, 6000);
}
